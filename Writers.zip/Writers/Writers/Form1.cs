﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Writers
{
    public partial class Form1 : Form
    {
        Find fd = new Find();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(Object sender, FormClosingEventArgs e) 
        {
            EventArgs eg=new EventArgs();
            DialogResult dia = MessageBox.Show("do you want to close application?");
            if(dia==DialogResult.Yes)
            {
                saveAsToolStripMenuItem_Click(sender, eg);
                Application.Exit();
            }
            else
            {
                e.Cancel=true;
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            saveToolStripMenuItem_Click(sender, e);
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            DialogResult result = openFileDialog1.ShowDialog();
           
            if (result == DialogResult.OK) // Test result.
	         {
		        string file = openFileDialog1.FileName;
		        try
		        {
		            richTextBox1.Text = File.ReadAllText(file);
		        }
		        catch (Exception ex)
		        {
                    MessageBox.Show(ex.ToString());
		        }
	        }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string words =  richTextBox1.Text;
            string lines = words + "\r\n";

            // Write the string to a file.
            System.IO.StreamWriter file = new System.IO.StreamWriter(@"fileinfo.txt");
            file.WriteLine(lines);
            file.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dia = MessageBox.Show("do you want to close application?","yes",MessageBoxButtons.YesNo);
            switch (dia)
            {
                case DialogResult.Yes:
                    {
                        saveAsToolStripMenuItem_Click(sender, e);
                        this.Close();
                        break;
                    }
                case DialogResult.No:
                    {
                        this.Text = "[No]";
                        break;
                    }
            }
        }

        /*
        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Replace rf = new Replace(richTextBox1.Text);
            rf.Show();
            
        }*/

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
             richTextBox1.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
             richTextBox1.Paste();
        }

        private void countToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            String text =  richTextBox1.Text.Trim();
            int wordCount = 0, index = 0;

            while (index < text.Length)
            {
                // check if current char is part of a word
                while (index < text.Length && Char.IsWhiteSpace(text[index]) == false)
                    index++;

                wordCount++;

                // skip whitespace until next word
                while (index < text.Length && Char.IsWhiteSpace(text[index]) == true)
                    index++;
            }
            MessageBox.Show("number of words are: "+wordCount);
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 fo = new Form1();
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter myStream=new StreamWriter(saveFileDialog1.FileName);
                    myStream.Write(richTextBox1.Text);
                    myStream.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
           // FormClosedEventArgs args=new FormClosedEventArgs();
            if(fd==null||fd.IsDisposed)
            {
                fd=new Find();
               // fd.FormClosed+=ChildFormClosed(sender,args);
            }
            fd.Show();
            
        }
          // when the form closes, detach the handler and clear the field
    void ChildFormClosed(object sender, FormClosedEventArgs args)
    {
        // detach the handler
        fd.FormClosed -= ChildFormClosed;

        // let GC collect it (and this way we can tell if it's closed)
        fd = null;
    }
    }
}
